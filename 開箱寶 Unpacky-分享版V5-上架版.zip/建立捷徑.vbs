Set fso = CreateObject("Scripting.FileSystemObject")
Set ws = CreateObject("WScript.Shell")
base = fso.GetParentFolderName(WScript.ScriptFullName)
Set lnk = ws.CreateShortcut(ws.SpecialFolders("Desktop") & "\�}�c�_ Unpacky.lnk")
lnk.TargetPath = base & "\�}�c�_ Unpacky.exe"
lnk.WorkingDirectory = base
lnk.IconLocation = base & "\�}�c�_ Unpacky.ico, 0"
lnk.Save
MsgBox "�ୱ���|�w�إߡI", 64, "�}�c�_ Unpacky"